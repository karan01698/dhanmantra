import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import '../../../../NewGames/backend/apis/methods.dart';
import '../../../../NewGames/games/color-pred/bottomsheet.dart';
import '../../../../authenticationsScreens/loginforgotregcontroller.dart';
import '../../../../backend/authenticanapi/controllerapi/registerapicontroller.dart';
import '../../../drawer/addmoney/updatebalance.dart';

class CombinedPage extends StatefulWidget {
  const CombinedPage({super.key});

  @override
  State<CombinedPage> createState() => _CombinedPageState();
}

class _CombinedPageState extends State<CombinedPage> {
  final List<TextEditingController> controllers =
  List.generate(100, (index) => TextEditingController());

  final TextEditingController totalJodiController =
  TextEditingController(text: "0");
  final TextEditingController totalAmountController =
  TextEditingController(text: "0");

  @override
  void initState() {
    super.initState();
    for (int i = 0; i < controllers.length; i++) {
      controllers[i].addListener(() {
        _updateAmount(); // keep this for amount
        _updateSummary(); // update jodi count based on > 0
      });
    }
  }

  void _updateSummary() {
    int totalJodi = 0;

    for (var controller in controllers) {
      final text = controller.text.trim();
      final value = int.tryParse(text) ?? 0;
      if (value > 0) {
        totalJodi += value;
      }
    }

    totalJodiController.text = totalJodi.toString();
  }

  void _updateAmount() {
    int totalAmount = 0;

    for (var controller in controllers) {
      final text = controller.text.trim();
      final value = int.tryParse(text) ?? 0;
      totalAmount += value;
    }

    totalAmountController.text = totalAmount.toString();
  }

  @override
  void dispose() {
    for (var controller in controllers) {
      controller.dispose();
    }
    totalJodiController.dispose();
    totalAmountController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final RegisterController userController = Get.put(RegisterController());
    final controller = Get.put(InsertBetController());
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        automaticallyImplyLeading:  false,
        elevation: 0,
        title: const Text(
          "Satta Matka ",
          style: TextStyle(color: Colors.white, fontSize: 22),
        ),

        // centerTitle: true,
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12.0),
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                elevation: 8,
                backgroundColor: Colors.yellow.withOpacity(0.2),
                // 🔶 Transparent yellow
                shadowColor: Colors.blue,
                // 🔵 Blue shadow
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side: const BorderSide(
                      color: Colors.yellow, width: 2), // 🔶 Yellow border
                ),
              ),
              onPressed: () {
                // Optional: Navigate to balance screen or do something
              },
              child: Obx(() {
                final balance = double.tryParse(
                    userController.userProfile.value?.balance.toString() ??
                        '0.0') ??
                    0.0;
                final bonus = double.tryParse(
                    userController.userProfile.value?.bonus.toString() ??
                        '0.0') ??
                    0.0;
                final total = balance + bonus;

                return Text(
                  "₹${total.toStringAsFixed(2)}",
                  style: const TextStyle(
                    color: Colors.white, // ✅ White text
                    fontWeight: FontWeight.bold,
                  ),
                );
              }),
            ),
          ),
        ],
      ),
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Column(
          children: [
            // const Padding(
            //   padding: EdgeInsets.all(8.0),
            //   child: Text(
            //     "Enter Values",
            //     style: TextStyle(color: Colors.white, fontSize: 20),
            //   ),
            // ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: GridView.builder(
                  physics: const BouncingScrollPhysics(),
                  itemCount: 100,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 5,
                    crossAxisSpacing: 15,
                    mainAxisSpacing: 20,
                    childAspectRatio: 4 / 7,
                  ),
                  itemBuilder: (context, index) {
                    final number = (index + 1).toString().padLeft(2, '0');
                    return GameInputBox(
                      label: number,
                      controller: controllers[index],
                    );
                  },
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: SummaryBox(
                totalJodiController: totalJodiController,
                totalAmountController: totalAmountController,
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.amber,
                foregroundColor: Colors.black,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                padding:
                EdgeInsets.symmetric(horizontal: 40, vertical: 12),
              ),
              onPressed: () async {
                if (totalJodiController == null ||
                    totalAmountController.text.isEmpty) {
                  Get.snackbar(
                    "Error",
                    "Please select a number and enter amount",
                    backgroundColor: Colors.red,
                    colorText: Colors.white,
                  );
                  return;
                }

                String? phone =
                await RegistrationController.getPhoneNumber();

                if (phone == null || phone.isEmpty) {
                  Get.snackbar(
                    "Error",
                    "Phone number not found. Please log in.",
                    backgroundColor: Colors.red,
                    colorText: Colors.white,
                  );
                  return;
                }

                // ✅ Set the date from date controller
                final UpdaBalanceControllersss datecontroller =
                Get.put(UpdaBalanceControllersss());
                datecontroller.setCurrentDate();
                await AppServices.updateWalletBalance(
                    "e", totalAmountController.text, 'SUB');
                // ✅ Call the insertBet API with amount and number (as profit)
                await controller.insertBet(
                  token: "ADFHNSAMALOUAAKL",
                  date: datecontroller.selectedDate.value,
                  gamename: "Satta Matka",
                  phone: phone,
                  amount: totalAmountController.text,
                  // ✅ Amount passed here
                  profit: totalJodiController.text,// ✅ Number passed here
                );

                // ✅ Show success snackbar
                Get.snackbar(
                  "Success",
                  "Number ${totalJodiController.text} placed with amount ₹${totalAmountController.text}",
                  backgroundColor: Colors.green,
                  colorText: Colors.white,
                );
              },
              child: Text("Submit",
                  style: TextStyle(
                      fontWeight: FontWeight.bold, fontSize: 16)),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}

class GameInputBox extends StatelessWidget {
  final String label;
  final TextEditingController controller;

  const GameInputBox({
    super.key,
    required this.label,
    required this.controller,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          label,
          style: const TextStyle(color: Colors.white, fontSize: 12),
        ),
        const SizedBox(height: 5),
        Container(
          decoration: BoxDecoration(
            color: const Color(0xFF1D1D1D),
            borderRadius: BorderRadius.circular(10),
          ),
          child: SizedBox(
            height: 70,
            width: 60,
            child: TextField(
              controller: controller,
              style: const TextStyle(color: Colors.white),
              keyboardType: TextInputType.number,
              textAlign: TextAlign.center,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                contentPadding:
                EdgeInsets.symmetric(horizontal: 10, vertical: 22),
                isDense: true,
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.white),
                ),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.white),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class SummaryBox extends StatelessWidget {
  final TextEditingController totalJodiController;
  final TextEditingController totalAmountController;

  const SummaryBox({
    super.key,
    required this.totalJodiController,
    required this.totalAmountController,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1D1D1D),
        border: Border.all(color: Colors.white),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          _buildSummaryRow("Total Jodi", totalJodiController),
          const SizedBox(height: 16),
          _buildSummaryRow("Total Amount", totalAmountController),
        ],
      ),
    );
  }

  Widget _buildSummaryRow(String title, TextEditingController controller) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(
            width: 90,
            height: 40,
            child: TextField(
              controller: controller,
              keyboardType: TextInputType.number,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                contentPadding: const EdgeInsets.symmetric(vertical: 10),
                enabledBorder: OutlineInputBorder(
                  borderSide: const BorderSide(color: Colors.white),
                  borderRadius: BorderRadius.circular(6),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: const BorderSide(color: Colors.white),
                  borderRadius: BorderRadius.circular(6),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class GradientButton extends StatelessWidget {
  final String text;
  final VoidCallback onTap;

  const GradientButton({
    super.key,
    required this.text,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        height: 55,
        padding: const EdgeInsets.symmetric(vertical: 16),
        margin: const EdgeInsets.symmetric(horizontal: 24),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFFFFF3B0), Color(0xFFFFC940)],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          borderRadius: BorderRadius.circular(40),
        ),
        child: Center(
          child: Text(
            text,
            style: const TextStyle(
              color: Colors.black,
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
        ),
      ),
    );
  }
}

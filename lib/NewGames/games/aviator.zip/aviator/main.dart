import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart'; // Import provider
import 'package:winworld/backend/apis/methods.dart';
import 'package:winworld/games/aviator/game/provider.dart';
import 'package:winworld/games/aviator/package/src/chart/base/axis_chart/axis_chart_data.dart';
import 'package:winworld/games/aviator/package/src/chart/base/axis_chart/square.dart';
import 'package:winworld/games/aviator/package/src/chart/line_chart/line_chart.dart';
import 'package:winworld/games/aviator/package/src/chart/line_chart/line_chart_data.dart';
import 'dart:ui' as ui;

class AviatorCrashGame extends StatefulWidget {
  const AviatorCrashGame({
    super.key,
  });

  @override
  _AviatorCrashGameState createState() => _AviatorCrashGameState();
}

class _AviatorCrashGameState extends State<AviatorCrashGame>
    with SingleTickerProviderStateMixin {
  FlSpot? lastSpot;
  List<FlSpot> spots = [];
  Timer? timer;
  double multiplier = 1.0;
  double crashPoint = 0.0;
  int elapsedMillis = 0;
  ui.Image? dotImage;
  bool isCrashing = false;

  late AnimationController crashAnimationController;
  late Animation<Offset> crashAnimation;

  @override
  void initState() {
    super.initState();

    crashAnimationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    crashAnimation = Tween<Offset>(
      begin: const Offset(0, 0),
      end: const Offset(2, -2),
    ).animate(CurvedAnimation(
      parent: crashAnimationController,
      curve: Curves.easeInQuart,
    ));

    _initializeGame();
    _startUpdatingChart();
    _loadImage();
  }

  Future<void> _loadImage() async {
    final image = await _loadImageFromAssets('images/plane.png');
    setState(() {
      dotImage = image;
    });
  }

  Future<ui.Image> _loadImageFromAssets(String assetPath) async {
    final ByteData data = await rootBundle.load(assetPath);
    final Uint8List bytes = data.buffer.asUint8List();
    final ui.Image image = await decodeImageFromList(bytes);
    return image;
  }

  void _initializeGame() async {
    final probality = await AppServices.getProbality();
    crashPoint = probality[0].min +
        Random().nextDouble() * (probality[0].max - probality[0].min);
    spots = [const FlSpot(0, 1.0)];
    multiplier = 1.0; // Reset the multiplier
    Provider.of<AviatorProvider>(context, listen: false).makeBetLive();
    // Reset the provider's multiplier
    Provider.of<AviatorProvider>(context, listen: false).updateMultiplier(1.0);

    elapsedMillis = 0; // Reset the timer
    isCrashing = false; // Reset crashing state
  }

  void _startCrashAnimation() async {
    multiplier = 1.0; // Reset the multiplier

    // Reset the provider's multiplier
    Provider.of<AviatorProvider>(context, listen: false).updateMultiplier(1.0);
    Provider.of<AviatorProvider>(context, listen: false).clearBet();
    setState(() {
      isCrashing = true;
      lastSpot = spots.last; // Store the last spot before clearing
      spots.clear(); // Clear all spots except the last one
    });
    crashAnimationController.forward();
    await Future.delayed(const Duration(seconds: 1));
    crashAnimationController.reset();
    _startWaitingPeriod();
  }

  void _startWaitingPeriod() {
    // Access the provider to start the waiting period
    Provider.of<AviatorProvider>(context, listen: false).startWaitingPeriod();
    Future.delayed(const Duration(seconds: 10), () {
      _initializeGame(); // Reinitialize the game after waiting
      _startUpdatingChart(); // Restart the chart update loop

      // Access the provider to end the waiting period
      Provider.of<AviatorProvider>(context, listen: false).endWaitingPeriod();
    });
  }

  void _startUpdatingChart() {
    timer = Timer.periodic(const Duration(milliseconds: 50), (timer) {
      // Slower updates
      setState(() {
        elapsedMillis += 50; // Adjusted to match the new timer interval
        double xValue = elapsedMillis / 1000.0;

        // Further reduce the multiplier growth rates
        if (elapsedMillis < 1500) {
          multiplier +=
              0.003 + Random().nextDouble() * 0.005; // Very slow growth
        } else if (elapsedMillis < 5000) {
          multiplier += 0.005 + Random().nextDouble() * 0.01; // Slower growth
          multiplier += (Random().nextBool()
              ? 0.002
              : -0.002); // Smaller random variation
        } else {
          multiplier += 0.01 + Random().nextDouble() * 0.02; // Slower growth
          multiplier += (Random().nextBool()
              ? 0.005
              : -0.005); // Smaller random variation
        }

        // Update the provider's multiplier value
        Provider.of<AviatorProvider>(context, listen: false)
            .updateMultiplier(multiplier);

        if (!isCrashing) {
          spots.add(FlSpot(xValue, multiplier));
        }

        if (multiplier >= crashPoint && !isCrashing) {
          timer.cancel();
          _startCrashAnimation();
        }
      });
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    crashAnimationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    bool isWaiting = Provider.of<AviatorProvider>(context)
        .isWaiting; // Access waiting status

    return Container(
      decoration: const BoxDecoration(
        image: DecorationImage(
            image: AssetImage("images/bg.gif"), fit: BoxFit.fill),
      ),
      height: 300,
      child: Stack(
        children: [
          if (!isWaiting) ...[
            AnimatedBuilder(
              animation: crashAnimationController,
              builder: (context, child) {
                return LineChart(
                  LineChartData(
                    gridData: const FlGridData(show: false),
                    titlesData: FlTitlesData(
                      rightTitles: const AxisTitles(
                          sideTitles: SideTitles(showTitles: false)),
                      topTitles: const AxisTitles(
                          sideTitles: SideTitles(showTitles: false)),
                      leftTitles: AxisTitles(
                        sideTitles: SideTitles(
                          showTitles: true,
                          reservedSize: 30,
                          getTitlesWidget: (value, meta) {
                            return const CircleAvatar(
                              radius: 2,
                              backgroundColor: Colors.cyan,
                            );
                          },
                        ),
                      ),
                      bottomTitles: AxisTitles(
                        sideTitles: SideTitles(
                          showTitles: true,
                          getTitlesWidget: (value, meta) {
                            return const CircleAvatar(
                              radius: 2,
                              backgroundColor: Colors.white,
                            );
                          },
                        ),
                      ),
                    ),
                    lineBarsData: [
                      LineChartBarData(
                        spots:
                            isCrashing ? [] : spots, // Clear line when crashing
                        dotData: FlDotData(
                          getDotPainter: (p0, p1, p2, p3) {
                            return FlDotSquarePainter(
                              image: dotImage,
                              crashOffset:
                                  isCrashing ? crashAnimation.value : null,
                            );
                          },
                          show: true,
                          checkToShowDot: (spot, barData) {
                            if (isCrashing && lastSpot != null) {
                              return spot == lastSpot;
                            }
                            return spot.x == barData.spots.last.x;
                          },
                        ),
                        color: const Color(0xffe80439),
                        isStrokeCapRound: true,
                        belowBarData: BarAreaData(
                          show: !isCrashing,
                          color: const Color(0xffe80439).withOpacity(0.3),
                        ),
                      ),
                      if (isCrashing && lastSpot != null)
                        LineChartBarData(
                          spots: [lastSpot!],
                          dotData: FlDotData(
                            getDotPainter: (p0, p1, p2, p3) {
                              return FlDotSquarePainter(
                                image: dotImage,
                                crashOffset: crashAnimation.value,
                              );
                            },
                            show: true,
                          ),
                          show: true,
                          color: Colors.transparent,
                        ),
                    ],
                    minX: 0,
                    maxX: spots.isNotEmpty
                        ? spots.last.x + 1
                        : (lastSpot?.x ?? 1) + 1,
                    minY: 1.0,
                    maxY: spots.isNotEmpty
                        ? spots.last.y + 1
                        : (lastSpot?.y ?? 2) + 1,
                  ),
                );
              },
            ),
            Center(
              child: Text(
                '${multiplier.toStringAsFixed(2)}x',
                style: TextStyle(
                  fontSize: 40,
                  fontWeight: FontWeight.bold,
                  color: isCrashing ? Colors.red : Colors.white,
                ),
              ),
            ),
          ] else ...[
            const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(
                    color: Colors.white,
                  ),
                  SizedBox(height: 10),
                  Text(
                    "Waiting for next round...",
                    style: TextStyle(fontSize: 20, color: Colors.white),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}

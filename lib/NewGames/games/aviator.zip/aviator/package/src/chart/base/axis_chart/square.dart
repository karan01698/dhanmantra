import 'dart:ui' as ui;
import 'package:winworld/games/aviator/package/src/chart/base/axis_chart/axis_chart_data.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

// FlDotSquarePainter implementation
class FlDotSquarePainter extends FlDotPainter {
  final ui.Image? image;
  final Offset? crashOffset;

  FlDotSquarePainter({
    this.image,
    this.crashOffset,
  });

  @override
  void draw(Canvas canvas, FlSpot spot, Offset offsetInCanvas) {
    if (image == null) return;

    final adjustedOffset = crashOffset != null
        ? offsetInCanvas.translate(
            crashOffset!.dx *
                200, // Increased multiplier for more visible movement
            crashOffset!.dy *
                200, // Increased multiplier for more visible movement
          )
        : offsetInCanvas;

    canvas.drawImageRect(
      image!,
      Rect.fromLTWH(0, 0, image!.width.toDouble(), image!.height.toDouble()),
      Rect.fromCenter(
        center: adjustedOffset,
        width: 60,
        height: 60,
      ),
      Paint(),
    );
  }

  @override
  Size getSize(FlSpot spot) {
    return const Size(30, 30);
  }

  @override
  List<Object?> get props => [image, crashOffset];

  @override
  FlDotPainter lerp(FlDotPainter a, FlDotPainter b, double t) {
    if (b is FlDotSquarePainter) {
      return b;
    }
    return b;
  }

  @override
  // TODO: implement mainColor
  ui.Color get mainColor => throw UnimplementedError();
}

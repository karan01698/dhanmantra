import 'package:winworld/games/aviator/game/Utils/constants.dart';
import 'package:flutter/material.dart';

class BetBox extends StatelessWidget {
  final double betAmount;
  const BetBox({required this.betAmount, Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.cardBg,
        borderRadius: BorderRadius.circular(10),
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text('BET', style: AppTextStyles.body),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: AppColors.green,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text('\$$betAmount USD', style: AppTextStyles.header),
          ),
        ],
      ),
    );
  }
}

import 'package:fluttertoast/fluttertoast.dart';
import 'package:provider/provider.dart';
import 'package:winworld/backend/apis/methods.dart';
import 'package:winworld/games/aviator/game/Utils/constants.dart';
import 'package:flutter/material.dart';
import 'package:winworld/games/aviator/game/provider.dart';

class CustomButton extends StatelessWidget {
  final Color color;
  final TextStyle? textStyle;

  const CustomButton({
    super.key,
    this.color = AppColors.green, // Default green color
    this.textStyle,
  });

  @override
  Widget build(BuildContext context) {
    return Consumer<AviatorProvider>(
      builder: (context, value, child) {
        final isBetPlaced = value.isBetPlaced;
        return GestureDetector(
          onTap: () async {
            if (!isBetPlaced) {
              if (value.multiplier.toDouble() == 1.0) {
                final wallet = await AppServices.getWallet();
                final currentBalance = num.parse(wallet[0].balance);
                final betAmount = num.parse(value.betAmount);

                if (betAmount < 10) {
                  Fluttertoast.showToast(msg: "Minimum bet amount is 10");
                } else if (currentBalance >= betAmount) {
                  final email = await AppServices.getEmail();
                  await AppServices.updateWalletBalance(
                      email, (currentBalance - betAmount).toString());
                  value.placeBet();
                  Fluttertoast.showToast(msg: "Bet Placed");
                } else {
                  Fluttertoast.showToast(msg: "Insufficient Balance");
                }
              } else {
                Fluttertoast.showToast(msg: "Cannot Place Bet");
              }
            } else {
              final wallet = await AppServices.getWallet();
              final currentBalance = num.parse(wallet[0].balance);
              final prizeAmount =
                  ((double.tryParse(value.betAmount) ?? 0) * value.multiplier)
                      .toInt();
              final email = await AppServices.getEmail();
              await AppServices.updateWalletBalance(
                  email, (currentBalance + prizeAmount).toString());
              value.clearBet();
              Fluttertoast.showToast(msg: "Prize Added To Your Wallet");
            }
            // Your onTap action here
          },
          child: Container(
            width: 180,
            height: 60, // Increase height to accommodate both texts
            decoration: BoxDecoration(
              color: isBetPlaced
                  ? Colors.red
                  : color, // Button background color (green)
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                  width: 1,
                  color: isBetPlaced
                      ? Colors.red
                      : const Color(0xff88d572)), // Border color
            ),
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // "BET" text
                  Text(
                    isBetPlaced
                        ? value.multiplier.toDouble() == 1.0
                            ? "Waiting"
                            : value.isBetLive
                                ? "CASHOUT"
                                : "Waiting"
                        : "BET",
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 8), // Add some space between the texts
                  // "1.00 INR" text
                  Text(
                    value.isBetLive
                        ? "${((double.tryParse(value.betAmount) ?? 0) * value.multiplier).toStringAsFixed(2)} INR"
                        : "${value.betAmount}.00 INR",
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

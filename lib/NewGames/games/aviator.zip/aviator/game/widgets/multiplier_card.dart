import 'package:winworld/games/aviator/game/Utils/constants.dart';
import 'package:flutter/material.dart';

class MultiplierCard extends StatelessWidget {
  final double multiplier;
  const MultiplierCard({required this.multiplier, Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.cardBg,
        borderRadius: BorderRadius.circular(10),
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text('FUN MODE', style: AppTextStyles.body),
          const SizedBox(height: 8),
          Text('${multiplier.toStringAsFixed(2)}x',
              style: AppTextStyles.header.copyWith(color: AppColors.red)),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';

class AppColors {
  static const primary = Colors.black;
  static const secondary = Colors.white;
  static const green = Colors.green;
  static const red = Colors.red;
  static const cardBg = Color(0xFF1A1A1A);
}

class AppTextStyles {
  static const header = TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: AppColors.red);
  static const body = TextStyle(fontSize: 16, color: AppColors.secondary);
}

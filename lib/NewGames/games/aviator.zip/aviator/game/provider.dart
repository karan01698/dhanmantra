import 'package:flutter/material.dart';

class AviatorProvider with ChangeNotifier {
  bool _isWaiting = false;
  bool get isWaiting => _isWaiting;
  bool _isBetPlaced = false;
  bool get isBetPlaced => _isBetPlaced;
  bool _isBetLive = false;
  bool get isBetLive => _isBetLive;

  num _multiplier = 1.0;
  num get multiplier => _multiplier;

  num _crashPoint = 0.0; // Added crashPoint variable
  num get crashPoint => _crashPoint;

  String _betAmount = "10";
  String get betAmount => _betAmount;

  // Start the waiting period
  void startWaitingPeriod() {
    _isWaiting = true;
    notifyListeners();
  }

  void placeBet() {
    _isBetPlaced = true;
    notifyListeners();
  }

  void makeBetLive() {
    if (_isBetPlaced) {
      _isBetLive = true;
      notifyListeners();
    }
  }

  // Update the multiplier
  void updateMultiplier(num value) {
    _multiplier = value;
    notifyListeners();
  }

  // Update the crashPoint
  void updateCrashPoint(num value) {
    _crashPoint = value;
    notifyListeners();
  }

  // Update the bet amount
  void updateBetAmount(String amount) {
    _betAmount = amount;
    notifyListeners();
  }

  // End the waiting period
  void endWaitingPeriod() {
    _isWaiting = false;
    notifyListeners();
  }

  void clearBet() {
    _isBetPlaced = false;
    _isBetLive = false;
    notifyListeners();
  }
}

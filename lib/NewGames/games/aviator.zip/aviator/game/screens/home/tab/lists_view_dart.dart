import 'package:flutter/material.dart';

class VerticalList extends StatelessWidget {
  final List<Map<String, dynamic>> data = [
    {'avatar': Icons.person, 'id': 'd***4', 'amount': 100.0, 'multiplier': '2.23x', 'total': 223.0},
    {'avatar': Icons.person, 'id': 'd***4', 'amount': 100.0, 'multiplier': null, 'total': null},
    {'avatar': Icons.person, 'id': 'd***7', 'amount': 100.0, 'multiplier': '1.14x', 'total': 114.0},
    {'avatar': Icons.person, 'id': 'd***7', 'amount': 100.0, 'multiplier': '1.17x', 'total': 117.0},
    {'avatar': Icons.person, 'id': 'd***0', 'amount': 100.0, 'multiplier': '3.16x', 'total': 316.0},
    {'avatar': Icons.person, 'id': 'd***9', 'amount': 100.0, 'multiplier': '2.04x', 'total': 204.0},
    {'avatar': Icons.person, 'id': 'd***0', 'amount': 100.0, 'multiplier': '2.07x', 'total': 207.0},
    {'avatar': Icons.person, 'id': 'd***4', 'amount': 100.0, 'multiplier': '2.23x', 'total': 223.0},
    {'avatar': Icons.person, 'id': 'd***4', 'amount': 100.0, 'multiplier': null, 'total': null},
    {'avatar': Icons.person, 'id': 'd***7', 'amount': 100.0, 'multiplier': '1.14x', 'total': 114.0},
    {'avatar': Icons.person, 'id': 'd***7', 'amount': 100.0, 'multiplier': '1.17x', 'total': 117.0},
    {'avatar': Icons.person, 'id': 'd***0', 'amount': 100.0, 'multiplier': '3.16x', 'total': 316.0},
    {'avatar': Icons.person, 'id': 'd***9', 'amount': 100.0, 'multiplier': '2.04x', 'total': 204.0},
    {'avatar': Icons.person, 'id': 'd***0', 'amount': 100.0, 'multiplier': '2.07x', 'total': 207.0},
    {'avatar': Icons.person, 'id': 'd***4', 'amount': 100.0, 'multiplier': '2.23x', 'total': 223.0},
    {'avatar': Icons.person, 'id': 'd***4', 'amount': 100.0, 'multiplier': null, 'total': null},
    {'avatar': Icons.person, 'id': 'd***7', 'amount': 100.0, 'multiplier': '1.14x', 'total': 114.0},
    {'avatar': Icons.person, 'id': 'd***7', 'amount': 100.0, 'multiplier': '1.17x', 'total': 117.0},
    {'avatar': Icons.person, 'id': 'd***0', 'amount': 100.0, 'multiplier': '3.16x', 'total': 316.0},
    {'avatar': Icons.person, 'id': 'd***9', 'amount': 100.0, 'multiplier': '2.04x', 'total': 204.0},
    {'avatar': Icons.person, 'id': 'd***0', 'amount': 100.0, 'multiplier': '2.07x', 'total': 207.0},
    {'avatar': Icons.person, 'id': 'd***4', 'amount': 100.0, 'multiplier': '2.23x', 'total': 223.0},
    {'avatar': Icons.person, 'id': 'd***4', 'amount': 100.0, 'multiplier': null, 'total': null},
    {'avatar': Icons.person, 'id': 'd***7', 'amount': 100.0, 'multiplier': '1.14x', 'total': 114.0},
    {'avatar': Icons.person, 'id': 'd***7', 'amount': 100.0, 'multiplier': '1.17x', 'total': 117.0},
    {'avatar': Icons.person, 'id': 'd***0', 'amount': 100.0, 'multiplier': '3.16x', 'total': 316.0},
    {'avatar': Icons.person, 'id': 'd***9', 'amount': 100.0, 'multiplier': '2.04x', 'total': 204.0},
    {'avatar': Icons.person, 'id': 'd***0', 'amount': 100.0, 'multiplier': '2.07x', 'total': 207.0},
  ];

  // Helper function to check if multiplier is >= 2
  bool isMultiplierGreaterThanOrEqualToTwo(String? multiplier) {
    if (multiplier == null) return false;
    double value = double.tryParse(multiplier.replaceAll('x', '')) ?? 0;
    return value >= 2;
  }

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: data.length,
      itemBuilder: (context, index) {
        final item = data[index];

        // Check if multiplier is null and set it to '0.00x'
        String multiplier = item['multiplier'] ?? '0.00x';
        double total = item['total'] ?? 0.00;

        return SizedBox(
          height: 50, // Set a small fixed height for the card
          child: Column(
            children: [
              Card(
                color: multiplier != '0.00x' ? Color(0xff123304) : Color(0xff101113),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10), // Rounded corners
                  side: BorderSide(color: multiplier != '0.00x' ? Color(0xff304922) : Color(0xff2e2906), width: 1),
                ),
                child: Row(
                  children: [
                    SizedBox(
                      width: 40, // Size for the avatar
                      child: CircleAvatar(
                        radius: 10,
                        backgroundColor: Colors.white,
                        child: Icon(item['avatar'], color: Color(0xff123304), size: 20),
                      ),
                    ),
                    SizedBox(width: 8),
                    Text(
                      item['id'],
                      style: TextStyle(color: Colors.white, fontSize: 15),
                    ),
                    SizedBox(width: 40),
                    Text(
                      '${item['amount'].toStringAsFixed(2)}',
                      style: TextStyle(color: Colors.white, fontSize: 15),
                    ),
                    SizedBox(width: 40),
                    Padding(
                      padding: const EdgeInsets.only(left: 10.0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Container(
                            width: 50,
                            height: 20,
                            padding: const EdgeInsets.symmetric(horizontal: 7.0, vertical: 0.0),
                            decoration: BoxDecoration(
                              color: Color(0xff061f00).withOpacity(0.5),
                              borderRadius: BorderRadius.circular(30),
                            ),
                            child: Text(
                              multiplier,
                              style: TextStyle(
                                color: isMultiplierGreaterThanOrEqualToTwo(multiplier) ? Colors.blue : Colors.purple,
                                fontSize: 13,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(width: 40),
                    Text(
                      '${total.toStringAsFixed(2)}', // Display total as 0.00 if null
                      style: TextStyle(color: Colors.white, fontSize: 15),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

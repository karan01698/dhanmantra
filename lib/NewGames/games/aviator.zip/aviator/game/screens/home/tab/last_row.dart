import 'package:flutter/material.dart';

class AutoPlayCashOutWidget extends StatefulWidget {
  const AutoPlayCashOutWidget({super.key});

  @override
  State<AutoPlayCashOutWidget> createState() => _AutoPlayCashOutWidgetState();
}

class _AutoPlayCashOutWidgetState extends State<AutoPlayCashOutWidget> {
  bool isSwitchOn = false; 
  TextEditingController textController =
      TextEditingController(text: '1.10');
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          const SizedBox(width: 20), 
          Container(
            width: 180, 
            height: 40,
            padding: const EdgeInsets.only(bottom: 1),
            decoration: BoxDecoration(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(30),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Auto Cash Out',
                  style: TextStyle(
                      color: Color.fromARGB(255, 153, 152, 152),
                      fontSize: 14), // Slightly larger text for readability
                ),
                Transform.scale(
                  scale: 0.7, // Adjusted scale for better size
                  child: Switch(
                    value: isSwitchOn, // Bind the state to the switch
                    onChanged: (bool value) {
                      setState(() {
                        isSwitchOn = value; // Update the state on toggle
                      });
                    },
                    activeColor: Colors.green, // Color when switch is on
                    inactiveThumbColor: const Color(0xFF1B1C1E), // Off color
                    materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(width: 8), // Space between buttons

          // TextField for 1.10 value
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10.0),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(30),
                  color: Colors.black,
                ),
                child: Row(
                  children: [
                    SizedBox(
                      width: 50, // Adjust width for the TextField
                      child: TextField(
                        controller: textController, // Bind the controller
                        enabled: isSwitchOn, // Disable when switch is off
                        style: const TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF585858),
                        ),
                        decoration: InputDecoration(
                          border: InputBorder.none, // Remove default border
                          isDense: true, // Reduce padding
                          contentPadding:
                              const EdgeInsets.symmetric(vertical: 5),
                          hintText:
                              isSwitchOn ? null : 'Disabled', // Optional hint
                          hintStyle: const TextStyle(
                            color: Colors.grey, // Hint color when disabled
                          ),
                        ),
                        keyboardType: TextInputType.number, // Numeric input
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

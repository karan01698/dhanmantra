import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:winworld/games/aviator/game/provider.dart'; // Import provider

class NumberWidget extends StatelessWidget {
  const NumberWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<AviatorProvider>(
      builder: (context, aviatorProvider, child) {
        return Column(
          children: [
            Container(
              width: 160,
              height: 30,
              margin: const EdgeInsets.symmetric(vertical: 2.00),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: Colors.black,
              ),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  // Remove Icon (Top Left)
                  Align(
                    alignment: Alignment.topLeft,
                    child: IconButton(
                      onPressed: () {
                        int newValue = int.parse(aviatorProvider.betAmount) - 1;
                        aviatorProvider.updateBetAmount(newValue.toString());
                      },
                      icon: const Icon(
                        Icons.remove_circle_outline,
                        color: Color(0xFF585858),
                        size: 18,
                      ),
                    ),
                  ),
                  // Number (Center)
                  Center(
                    child: Text(
                      aviatorProvider.betAmount,
                      style: const TextStyle(
                        fontSize: 15,
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  // Add Icon (Top Right)
                  Align(
                    alignment: Alignment.topRight,
                    child: IconButton(
                      onPressed: () {
                        int newValue = int.parse(aviatorProvider.betAmount) + 1;
                        aviatorProvider.updateBetAmount(newValue.toString());
                      },
                      icon: const Icon(
                        Icons.add_circle_outline,
                        color: Color(0xFF585858),
                        size: 18,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Row(
              children: [
                Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        // Text for the left side (10.00)
                        GestureDetector(
                          onTap: () {
                            int newValue =
                                int.parse(aviatorProvider.betAmount) + 10;
                            aviatorProvider
                                .updateBetAmount(newValue.toString());
                          },
                          child: Container(
                            height: 20,
                            width: 60,
                            decoration: BoxDecoration(
                              color: const Color(0xff141517),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: const Center(
                              child: Text(
                                '10.00',
                                style: TextStyle(color: Color(0xff5d5e60)),
                              ),
                            ),
                          ),
                        ),
                        // Text for the top side (20.00)
                        GestureDetector(
                          onTap: () {
                            int newValue =
                                int.parse(aviatorProvider.betAmount) + 20;
                            aviatorProvider
                                .updateBetAmount(newValue.toString());
                          },
                          child: Container(
                            height: 20,
                            width: 60,
                            decoration: BoxDecoration(
                              color: const Color(0xff141517),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: const Center(
                              child: Text(
                                '20.00',
                                style: TextStyle(color: Color(0xff5d5e60)),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 3),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        // Text for the bottom side (50.00)
                        GestureDetector(
                          onTap: () {
                            int newValue =
                                int.parse(aviatorProvider.betAmount) + 50;
                            aviatorProvider
                                .updateBetAmount(newValue.toString());
                          },
                          child: Container(
                            height: 20,
                            width: 60,
                            decoration: BoxDecoration(
                              color: const Color(0xff141517),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: const Center(
                              child: Text(
                                '50.00',
                                style: TextStyle(color: Color(0xff5d5e60)),
                              ),
                            ),
                          ),
                        ),
                        // Text for the right side (100.00)
                        GestureDetector(
                          onTap: () {
                            int newValue =
                                int.parse(aviatorProvider.betAmount) + 100;
                            aviatorProvider
                                .updateBetAmount(newValue.toString());
                          },
                          child: Container(
                            height: 20,
                            width: 60,
                            decoration: BoxDecoration(
                              color: const Color(0xff141517),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: const Center(
                              child: Text(
                                '100.00',
                                style: TextStyle(color: Color(0xff5d5e60)),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ],
        );
      },
    );
  }
}

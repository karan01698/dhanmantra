import 'package:flutter/material.dart';

class HorizontalListView extends StatelessWidget {
  final List<String> multipliers = [
    '2.33x',
    '1.43x',
    '5.23x',
    '1.00x',
    '2.00x',
    '1.50x',
    '2.01x',
    '1.23x',
    '4.00x',
    '1.23x',
  ];

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // Horizontal ListView with clipping
        ClipRect(
          child: SizedBox(
            height: 60, // Adjust height for horizontal ListView
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: multipliers.length,
              itemBuilder: (context, index) {
                // Extract the numeric part of the multiplier
                final numericValue =
                    double.tryParse(multipliers[index].replaceAll('x', '')) ?? 0.0;

                // Check if the value is 2 or greater
                final isTwoOrMore = numericValue >= 2.0;

                return Container(
                  width: 35,
                  margin: const EdgeInsets.symmetric(horizontal: 5.0, vertical: 6),
                  decoration: BoxDecoration(
                    color: Colors.black, // Container color remains constant
                    borderRadius: BorderRadius.circular(30),
                  ),
                  child: Center(
                    child: Text(
                      multipliers[index],
                      style: TextStyle(
                        color: isTwoOrMore ? Colors.blue : const Color(0xFF6842a9), // Conditional text color
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ),
        // Elevated Button on top-right with solid background
        Positioned(
          top: 0,
          right: 0,
          child: GestureDetector(
            onTap: () {
              // Navigate to the new screen with multipliers data
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => FullListView(multipliers: multipliers),
                ),
              );
            },
            child: Container(
              height: 25,
              color: const Color(0xff0e0e0e),
              child: Container(
                height: 22,
                padding: const EdgeInsets.symmetric(horizontal: 3),
                decoration: BoxDecoration(
                  color: const Color(0xFF26252a), // Solid background color
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(width: 1, color: const Color(0xFF2e2f33)),
                ),
                child: Row(
                  children: const [
                    Icon(Icons.watch_later, color: Color(0xff77787c), size: 18),
                    Icon(Icons.arrow_drop_down_outlined, color: Color(0xff77787c), size: 20),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class FullListView extends StatelessWidget {
  final List<String> multipliers;

  const FullListView({Key? key, required this.multipliers}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Full List View"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: GridView.builder(
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 7, // 4 items per row
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
          ),
          itemCount: multipliers.length,
          itemBuilder: (context, index) {
            // Parse numeric value from the multiplier string
            final numericValue =
                double.tryParse(multipliers[index].replaceAll('x', '')) ?? 0.0;

            // Determine the text color based on the numeric value
            final textColor = numericValue >= 2.0
                ? Colors.blue
                : const Color(0xFF6842a9); // Purple for values < 2.0

            // Calculate height and width based on string length

             // Adjust size dynamically

            return Container(
              // Dynamic width
              decoration: BoxDecoration(
                color: Colors.black,
                borderRadius: BorderRadius.circular(30), // Fixed radius
              ),
              child: Center(
                child: Text(
                  multipliers[index],
                  style: TextStyle(
                    color: textColor,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

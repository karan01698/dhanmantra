import 'package:winworld/backend/apis/methods.dart';
import 'package:winworld/backend/models/userbalance.dart';
import 'package:winworld/games/aviator/game/Utils/constants.dart';
import 'package:winworld/games/aviator/game/screens/home/tab/tab_view.dart';
import 'package:winworld/games/aviator/main.dart';
import 'package:flutter/material.dart';
import 'listview/horizotal_header_list.dart';

class AviatorScreen extends StatefulWidget {
  final UserBalance balanceData;
  const AviatorScreen({super.key, required this.balanceData});

  @override
  State<AviatorScreen> createState() => _AviatorScreenState();
}

class _AviatorScreenState extends State<AviatorScreen> {
  Stream<List<UserBalance>> walletStream() async* {
    while (true) {
      await Future.delayed(Duration.zero);
      final chatMessages = await AppServices.getWallet();
      yield chatMessages;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromARGB(255, 0, 0, 0),
      appBar: AppBar(
        backgroundColor: const Color(0xff1b1c1e),
        title: const Row(
          children: [
            Text(
              'Aviator',
              style: TextStyle(
                  color: Color(0xFFa21740), fontWeight: FontWeight.bold),
            ),

            SizedBox(width: 8), // Add space between text and icon
          ],
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                StreamBuilder(
                    stream: walletStream(),
                    builder: (context, snapshot) {
                      if (snapshot.hasData) {
                        return Text(
                            num.parse(snapshot.data![0].balance)
                                .toStringAsFixed(2),
                            style: AppTextStyles.body
                                .copyWith(color: AppColors.green));
                      }
                      return Container();
                    }),
                const SizedBox(
                  width: 2,
                ),
                Text('INR',
                    style: AppTextStyles.body.copyWith(
                        color: const Color(0xff868789), fontSize: 12)),
              ],
            ),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              const SizedBox(height: 10),
              SizedBox(height: 30, child: HorizontalListView()),
              const SizedBox(height: 10),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 12),
                child: AviatorCrashGame(),
              ),
              const SizedBox(height: 8),
              SizedBox(height: 800, child: TabBarExample()),
              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
    );
  }
}

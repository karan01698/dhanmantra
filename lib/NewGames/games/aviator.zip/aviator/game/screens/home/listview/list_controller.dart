import 'package:get/get.dart';

class MultiplierController extends GetxController {
  // Observable for toggling list visibility
  var showFullList = false.obs;

  // List of multipliers
  final List<String> multipliers = ["1.33x", "3.94x", "1.05x", "2.03x"];

  // Toggle visibility of the list
  void toggleListVisibility(bool value) {
    showFullList.value = value;
  }
}

import 'package:flutter/material.dart';

class CustomContainer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Row(

      children: [
        Column(
          children: [
            Row(

              spacing: 30,
              children: [
                // Text for the left side (20)
                Container(

                  height: 20,
                  width:60,
                  decoration: BoxDecoration(
                     color: Color(0xff141517),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Center(child: Text('1.00', style: TextStyle(color: Color (0xff5d5e60)))),
                ),
                // Text for the top side (15)
                Container(
                  height: 20,
                  width:60,
                  decoration: BoxDecoration(
                    color: Color(0xff141517),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Center(child: Text('2.00', style: TextStyle(color: Color (0xff5d5e60)))),
                ),
                // Text for the bottom side (50)

              ],
            ),
            SizedBox(height: 3,),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              spacing: 30,
              children: [ Container(
              height: 20,
                width:60,
              decoration: BoxDecoration(
                color: Color(0xff141517),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Center(child: Text('5.00', style: TextStyle(color: Color (0xff5d5e60)))),
            ),
              // Text for the right side (20)
              Container(
                height: 20,
                width:60,
                decoration: BoxDecoration(
                  color: Color(0xff141517),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Center(child: Text('10.00', style: TextStyle(color:Color (0xff5d5e60)))),
              ),],)
          ],
        ),

      ],

    );
  }
}


import 'package:winworld/games/aviator/game/screens/home/tab/plus_minus.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../widgets/custom_button.dart';
import 'last_row.dart';
import 'lists_view_dart.dart';

class TabControllerGetX extends GetxController {
  var currentIndex = 0.obs; // Observable to hold the current tab index

  void changeTab(int index) {
    currentIndex.value =
        index; // Change the tab index when the user taps on a tab
  }
}

class TabBarExample extends StatelessWidget {
  final TabControllerGetX tabController = Get.put(TabControllerGetX());

  TabBarExample({super.key}); // GetX controller for managing state

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Custom TabBar
        Obx(() {
          return Container(
            padding: const EdgeInsets.only(top: 10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(15.0),
              color: const Color(0xFF1B1C1E),
            ),
            child: Column(
              children: [
                Container(
                  height: 22.0,
                  width: 165,
                  decoration: BoxDecoration(
                      color: Colors.black,
                      borderRadius: BorderRadius.circular(20)),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      GestureDetector(
                        onTap: () => tabController.changeTab(0),
                        child: Container(
                          width: 80,
                          height: 20,
                          decoration: BoxDecoration(
                            color: tabController.currentIndex.value == 0
                                ? Colors.grey[
                                    800] // No solid color if image is used
                                : Colors.black,
                            // Inactive tab background color
                            borderRadius: BorderRadius.circular(10.0),
                            // Rounded corners for the container
                            // No image for inactive tab
                          ),
                          child: const Center(
                            child: Text(
                              'Bet',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                      ),
                      GestureDetector(
                        onTap: () => tabController.changeTab(1),
                        child: Container(
                          height: 20,
                          width: 80,
                          decoration: BoxDecoration(
                            color: tabController.currentIndex.value == 1
                                ? Colors.grey[
                                    800] // No solid color if image is used
                                : Colors.black,
                            // Inactive tab background color
                            borderRadius: BorderRadius.circular(10.0),
                            // Rounded corners for the container
                            // image: tabController.currentIndex.value == 1
                            //     ? DecorationImage(
                            //         image: AssetImage(
                            //             'assets/home/istockphoto-1347283792-612x612.png'),
                            //         // Path to your image
                            //         fit: BoxFit
                            //             .cover, // Fit the image to cover the container
                            //       )
                            //     : null, // No image for inactive tab
                          ),
                          padding: const EdgeInsets.symmetric(
                              vertical: 0.0, horizontal: 23),
                          child: const Text(
                            'Auto',
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(
                  height: 5,
                ),
                const Row(
                  // Ensure Row only takes the space required by its children

                  children: [
                    Column(
                      children: [
                        Padding(
                          padding: EdgeInsets.only(left: 20),
                          child: NumberWidget(),
                        ),
                        SizedBox(
                          height: 1,
                        ),
                        // Padding(
                        //   padding: const EdgeInsets.only(left: 12),
                        //   child: CustomContainer(),
                        // ),
                      ],
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    CustomButton(),
                  ],
                ),
                const SizedBox(
                  height: 10,
                ),
                const Divider(
                  color: Colors.black,
                  // Line color
                  height: 2,

                  // Divider height
                  thickness: 2,
                  // Line thickness
                  indent: 0,
                  // Space before the line starts
                  endIndent: 0, // Space after the line ends
                ),
                tabController.currentIndex == 1
                    ? const AutoPlayCashOutWidget()
                    : Container(),
              ],
            ),
          );
        }),
        SizedBox(
          height: 20,
        ),

        // TabBarView with content for each tab
        SizedBox(height: 300, child: VerticalList()),
      ],
    );
  }
}
